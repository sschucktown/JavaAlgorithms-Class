
package eightpuzzle;
import java.util.Arrays;
import java.util.Scanner;

public class EightPuzzle
{
    
    Scanner myScan = new Scanner(System.in);
    
    public EightPuzzle(int[] goalState)//constructor
    {
        
//        System.out.println("Please enter the goal state: ");
//        for(int i = 0; i < goalState.length; i++)
//        {
//            goalState[i] = myScan.nextInt();
//        }
//        System.out.println(Arrays.toString(goalState));//test
//        checkReachable(goalState);
    }
    
    public boolean checkReachable(int [] goalState)
    {
        boolean result = false;
        int inversionCount = 0;
        for(int i = 0; i < goalState.length; i++)
        {
            for (int j = i +1; j < goalState.length; j++)
            if(goalState[i] > goalState[j])
            {
                inversionCount++;
            }
            if(goalState[i] == 0 && i%2 == 1)
            {
                inversionCount++;
            }
        }
        System.out.println(inversionCount);//test for num of inversions
        if(inversionCount % 2 == 0)
        {
            result = true;
        }
        System.out.println(result);//test boolean value
        return result;
    }
    public void solve()
    {
        
    }
    
    public void printPath()
    {
        
    }
    
    public LinkedList makeChildren(int goalState)
    {
        LinkedList result = null;
        return result;
    }
    
    public int Manhattan(int[] firstState, int[] goalState)
    {
        int rowSize = 3;
        int result = 0;//sum of distance
//        System.out.println("Please enter the first state: ");
//        for(int i = 0; i < firstState.length; i++)
//        {
//            firstState[i] = myScan.nextInt();
//        }
        for(int i =0; i< firstState.length; i++)
        {
            for(int j = 0; j < firstState.length; j++)
                if(firstState[i] == goalState[j])
                {
                    if(firstState[i] ==0) continue;
                    result += (Math.abs(i/rowSize - j/rowSize) + Math.abs(i%rowSize - j%rowSize));
                    System.out.println(result);
                }
            
        }
        return result;
    }
    
}
