
package eightpuzzle;


public class BoardState
{
    
}
