/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eightpuzzle;


public class PriorityQueue extends Queue
{
	
	public PriorityQueue()
	{
		super();
	}
	
	public void priorityEnqueue(Comparable<Object> item)
	{
		// You need to implement this!
	} 

	public Comparable<Object> find(Comparable<Object> item)
	{
		// You need to implement this!
		return null; // I put this here temporarily. Please remove.
	} 

}

