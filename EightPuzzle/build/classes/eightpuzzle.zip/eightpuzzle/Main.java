
package eightpuzzle;


public class Main {

	public static void main(String[] args) 
        {
//            int [] goalState = {1,0,3,7,2,5,8,4,6};//restore after testing 
//            int [] goalState = { 0, 2, 1, 3, 4, 5, 8, 7, 6 };
            int [] goalState = { 1,2,3,4,5,6,7,8,0};
            int [] firstState = {0,2,1,4,3,5,6,7,8};//restore after testing
             EightPuzzle test = new EightPuzzle(goalState);
             test.checkReachable(goalState);
             test.Manhattan(firstState, goalState);
	}

}

